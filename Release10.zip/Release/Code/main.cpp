#include <iostream>
#include "persons.h"
#include "interface.h"

using namespace std;


int main(){


    InterFace ifDisp;
    ifDisp.runInterFace(); //opens the interface for user 
    
    return 0;
}
